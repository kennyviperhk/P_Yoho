#!/bin/bash

brew update
brew install git
brew install doxygen
