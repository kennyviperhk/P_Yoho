This Arduino Sketch requires the [https://github.com/bakercp/PacketSerial](https://github.com/bakercp/PacketSerial) and [OSC](https://github.com/CNMAT/OSC/) libraries.

To install, download the library, place it in your Arduino libraries folder, and restart the Arduino IDE.
